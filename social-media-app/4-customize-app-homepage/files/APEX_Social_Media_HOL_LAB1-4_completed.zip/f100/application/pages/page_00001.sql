prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.4'
,p_default_workspace_id=>4206878434042097
,p_default_application_id=>100
,p_default_id_offset=>4400484781339811
,p_default_owner=>'TEST'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Timeline'
,p_alias=>'HOME'
,p_step_title=>'APEX Social Media'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_overwrite_navigation_list=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'TEST'
,p_last_upd_yyyymmddhh24miss=>'20230404193325'
);
wwv_flow_imp.component_end;
end;
/
