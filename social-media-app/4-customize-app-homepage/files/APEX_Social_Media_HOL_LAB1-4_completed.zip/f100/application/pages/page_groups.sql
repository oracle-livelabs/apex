prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.4'
,p_default_workspace_id=>4206878434042097
,p_default_application_id=>100
,p_default_id_offset=>4400484781339811
,p_default_owner=>'TEST'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(63082141808395591341)
,p_group_name=>'Administration'
);
wwv_flow_imp.component_end;
end;
/
