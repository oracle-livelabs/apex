prompt --application/shared_components/navigation/tabs/parent
begin
--   Manifest
--     TOP LEVEL TABS: 102
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.4'
,p_default_workspace_id=>4206878434042097
,p_default_application_id=>102
,p_default_id_offset=>178159678296192488844
,p_default_owner=>'TEST'
);
null;
wwv_flow_imp.component_end;
end;
/
