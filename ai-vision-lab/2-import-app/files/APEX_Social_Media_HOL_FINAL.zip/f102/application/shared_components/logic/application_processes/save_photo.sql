prompt --application/shared_components/logic/application_processes/save_photo
begin
--   Manifest
--     APPLICATION PROCESS: SAVE_PHOTO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.4'
,p_default_workspace_id=>4206878434042097
,p_default_application_id=>102
,p_default_id_offset=>178159678296192488844
,p_default_owner=>'TEST'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(225666260216864826735)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SAVE_PHOTO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  l_photo_clob clob;',
'  l_photo_blob blob;',
'begin',
'  l_photo_clob := apex_application.g_clob_01;',
'',
'  l_photo_blob := apex_web_service.clobbase642blob(',
'                    p_clob => l_photo_clob',
'                  );',
'',
'  if not apex_collection.collection_exists(''PHOTOS'') then',
'    apex_collection.create_collection(p_collection_name => ''PHOTOS'');',
'  end if;',
'',
'  apex_collection.add_member(p_collection_name => ''PHOTOS'', p_blob001 => l_photo_blob);',
'',
'  apex_json.open_object;',
'  apex_json.write(',
'    p_name => ''result'',',
'    p_value => ''success''',
'  );',
'  apex_json.close_object;',
'exception',
'  when others then',
'    apex_json.open_object;',
'    apex_json.write(',
'      p_name => ''result'',',
'      p_value => ''fail''',
'    );',
'    apex_json.close_object;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
);
wwv_flow_imp.component_end;
end;
/
