prompt --application/shared_components/plugins/dynamic_action/com_oracle_apex_enhanced_file_uploader
begin
--   Manifest
--     PLUGIN: COM.ORACLE.APEX.ENHANCED_FILE_UPLOADER
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.4'
,p_default_workspace_id=>4206878434042097
,p_default_application_id=>102
,p_default_id_offset=>178159678296192488844
,p_default_owner=>'TEST'
);
wwv_flow_imp_shared.create_plugin(
 p_id=>wwv_flow_imp.id(235418723369888032539)
,p_plugin_type=>'DYNAMIC ACTION'
,p_name=>'COM.ORACLE.APEX.ENHANCED_FILE_UPLOADER'
,p_display_name=>'Enhanced File Uploader'
,p_category=>'EXECUTE'
,p_image_prefix => nvl(wwv_flow_application_install.get_static_plugin_file_prefix('DYNAMIC ACTION','COM.ORACLE.APEX.ENHANCED_FILE_UPLOADER'),'')
,p_javascript_file_urls=>'#PLUGIN_FILES#enhancedFileUpload#MIN#.js'
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function render(',
'             p_dynamic_action in apex_plugin.t_dynamic_action,',
'             p_plugin         in apex_plugin.t_plugin )',
'    return apex_plugin.t_dynamic_action_render_result is',
'',
'    l_result                    apex_plugin.t_dynamic_action_render_result;',
'',
'    c_enable_image_resize       constant boolean          := case when p_dynamic_action.attribute_01 = ''Y'' then true else false end;',
'    c_max_image_size            constant number           := p_dynamic_action.attribute_02;',
'    c_enable_image_preview      constant boolean          := case when p_dynamic_action.attribute_03 = ''Y'' then true else false end;',
'    c_preview_container         constant varchar2( 255 )  := p_dynamic_action.attribute_04;',
'    c_items_to_submit           constant varchar2( 4000 ) := p_dynamic_action.attribute_08;',
'    c_show_processing           constant boolean          := case when p_dynamic_action.attribute_09 = ''Y'' then true else false end;',
'    c_cancel_uploads_esc        constant boolean          := case when p_dynamic_action.attribute_10 = ''Y'' then true else false end;',
'    c_file_processing_function  constant varchar2( 4000 ) := coalesce( p_dynamic_action.attribute_11, ''null'' );',
'',
'    l_component_config_json     clob := empty_clob();',
'',
'    function get_da_item_element( p_action_id in number ) return varchar2 is',
'      l_da_element  apex_application_page_da.when_element%type;',
'      c_app_id      constant number := nv( ''APP_ID'' );',
'',
'      cursor l_cur_da_element is',
'        select aapda.affected_elements',
'          from apex_application_page_da_acts aapda',
'         where aapda.application_id = c_app_id',
'           and aapda.action_id = p_action_id',
'           and aapda.affected_elements_type_code = ''ITEM'';',
'    begin',
'      open l_cur_da_element;',
'      fetch l_cur_da_element',
'        into l_da_element;',
'      close l_cur_da_element;',
'',
'      return l_da_element;',
'',
'    end get_da_item_element;',
'',
'  begin',
'    -- build component config json',
'    apex_json.initialize_clob_output;',
'    apex_json.open_object();',
'    ',
'    apex_json.write( ''affectedElement'',',
'                     get_da_item_element( p_action_id => p_dynamic_action.id ) );',
'    apex_json.write( ''enableImageResize'',',
'                     c_enable_image_resize );',
'    apex_json.write( ''maxImageSize'',',
'                     c_max_image_size );',
'    apex_json.write( ''enableImagePreview'',',
'                     c_enable_image_preview );',
'    apex_json.write( ''previewContainer'',',
'                     c_preview_container );',
'    apex_json.write( ''itemsToSubmit'',',
'                     c_items_to_submit );',
'    apex_json.write( ''showProcessing'',',
'                     c_show_processing );',
'    apex_json.write( ''cancelWithEscape'',',
'                     c_cancel_uploads_esc );',
'    apex_json.write( ''ajaxIdentifier'',',
'                     apex_plugin.get_ajax_identifier );',
'    apex_json.close_object();',
'    --',
'    l_component_config_json := apex_json.get_clob_output;',
'    apex_json.free_output;',
'    -- da javascript function',
'    l_result.javascript_function := ''function(){apex.da.enhancedFileUpload(this,'' || l_component_config_json ||',
'                                    '','' || c_file_processing_function || '');}'';',
'    --',
'    return l_result;',
'    --',
'  end render;',
'',
'function ajax(',
'             p_dynamic_action in apex_plugin.t_dynamic_action,',
'             p_plugin         in apex_plugin.t_plugin )',
'  return apex_plugin.t_dynamic_action_ajax_result is',
'',
'  l_result               apex_plugin.t_dynamic_action_ajax_result;',
'',
'  c_storage_collection   constant varchar2( 50 ) := ''COLLECTION'';',
'  c_storage_plsql        constant varchar2( 50 ) := ''PLSQL'';',
'',
'  c_save_in              constant varchar2( 50 )   := coalesce( p_dynamic_action.attribute_05, c_storage_collection );',
'  c_collection_name      constant varchar2( 255 )  := p_dynamic_action.attribute_06;',
'  c_plsql_code           constant varchar2( 4000 ) := p_dynamic_action.attribute_07;',
'  c_items_to_submit      constant varchar2( 4000 ) := p_dynamic_action.attribute_08;',
'  c_apex_storage_name    constant varchar2( 255 )  := apex_application.g_f01(1);',
'  c_file_metadata        constant varchar2( 4000 ) := apex_application.g_x03;',
'  c_plsql_code_upper     constant varchar2( 4000 ) := upper( c_plsql_code );',
'  ',
'  l_parameters           apex_exec.t_parameters;',
'  l_items_to_submit_arr  apex_t_varchar2;',
'',
'begin',
'  -- save in APEX collection',
'  if c_save_in = c_storage_collection then',
'      if not apex_collection.collection_exists( p_collection_name => c_collection_name ) then',
'          apex_collection.create_collection( p_collection_name => c_collection_name );',
'      end if;',
'',
'      for l_rec_file in ( select aaf.filename,',
'                                 aaf.mime_type,',
'                                 aaf.doc_size,',
'                                 aaf.blob_content',
'                            from apex_application_files aaf',
'                           where aaf.name = c_apex_storage_name ) loop',
'',
'          apex_collection.add_member(',
'              p_collection_name => c_collection_name,',
'              p_c001            => l_rec_file.filename,',
'              p_c002            => l_rec_file.mime_type,',
'              p_c003            => c_file_metadata,',
'              p_d001            => sysdate,',
'              p_n001            => l_rec_file.doc_size,',
'              p_blob001         => l_rec_file.blob_content',
'          );',
'',
'    end loop;',
'',
'  end if;',
'',
'  -- save using custom PL/SQL',
'  if c_save_in = c_storage_plsql then',
'      -- add parameters / bind variables',
'      l_items_to_submit_arr := apex_string.split( p_str => c_items_to_submit, p_sep => '','' );',
'      for i in 1..l_items_to_submit_arr.count',
'      loop',
'          if instr( c_plsql_code_upper, l_items_to_submit_arr(i) ) > 0 then',
'              apex_exec.add_parameter(',
'                  p_parameters => l_parameters,',
'                  p_name       => l_items_to_submit_arr(i),',
'                  p_value      => v( l_items_to_submit_arr(i) ) );',
'          end if;',
'      end loop;',
'      ',
'      if instr( c_plsql_code_upper, ''APEX$STORAGENAME'' ) > 0 then',
'          apex_exec.add_parameter(',
'              p_parameters => l_parameters,',
'              p_name       => ''APEX$STORAGENAME'',',
'              p_value      => c_apex_storage_name );',
'      end if;',
'      if instr( c_plsql_code_upper, ''APEX$FILENAME'' ) > 0 then',
'          apex_exec.add_parameter(',
'              p_parameters => l_parameters,',
'              p_name       => ''APEX$FILENAME'',',
'              p_value      => apex_application.g_x01 );',
'      end if;',
'      if instr( c_plsql_code_upper, ''APEX$MIMETYPE'' ) > 0 then',
'          apex_exec.add_parameter(',
'              p_parameters => l_parameters,',
'              p_name       => ''APEX$MIMETYPE'',',
'              p_value      => apex_application.g_x02 );',
'      end if;',
'      if instr( c_plsql_code_upper, ''APEX$METADATA'' ) > 0 then',
'          apex_exec.add_parameter(',
'              p_parameters => l_parameters,',
'              p_name       => ''APEX$METADATA'',',
'              p_value      => c_file_metadata );',
'      end if;',
'    ',
'      -- execute pl/sql',
'      apex_exec.execute_plsql(',
'          p_plsql_code      => c_plsql_code,',
'          p_auto_bind_items => false,',
'          p_sql_parameters  => l_parameters );',
'  end if;',
'',
'  -- delete original file',
'  delete from apex_application_files aaf',
'     where aaf.name = c_apex_storage_name;',
'  ',
'  sys.htp.init;',
'  sys.htp.p( ''{"success":true}'' );',
'',
'  return l_result;',
'exception when others then',
'    sys.htp.init;',
'    sys.htp.p( ''{"success":false}'' );',
'end ajax;'))
,p_api_version=>2
,p_render_function=>'render'
,p_ajax_function=>'ajax'
,p_standard_attributes=>'ITEM:REQUIRED:STOP_EXECUTION_ON_ERROR:WAIT_FOR_RESULT'
,p_substitute_attributes=>true
,p_subscribe_plugin_settings=>true
,p_help_text=>'Dynamic Action plugin which enhances the functionality of the built-in File Browse item and uploads files using AJAX.'
,p_version_identifier=>'1.0.0'
,p_about_url=>'https://oracle.github.io/apex/'
,p_files_version=>235
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(235418815292577052321)
,p_plugin_id=>wwv_flow_imp.id(235418723369888032539)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>1
,p_display_sequence=>10
,p_prompt=>'Enable Image Resize'
,p_attribute_type=>'CHECKBOX'
,p_is_required=>false
,p_default_value=>'N'
,p_is_translatable=>false
,p_help_text=>'This option enables image resizing before the file is uploaded to the server.'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(235418867268425062673)
,p_plugin_id=>wwv_flow_imp.id(235418723369888032539)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>2
,p_display_sequence=>20
,p_prompt=>'Max. Image Size'
,p_attribute_type=>'INTEGER'
,p_is_required=>true
,p_default_value=>'1024'
,p_is_translatable=>false
,p_depending_on_attribute_id=>wwv_flow_imp.id(235418815292577052321)
,p_depending_on_has_to_exist=>true
,p_depending_on_condition_type=>'EQUALS'
,p_depending_on_expression=>'Y'
,p_help_text=>'This option downscales the image to fit into max * max size.'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(235418877867363065083)
,p_plugin_id=>wwv_flow_imp.id(235418723369888032539)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>3
,p_display_sequence=>30
,p_prompt=>'Enable Image Preview'
,p_attribute_type=>'CHECKBOX'
,p_is_required=>false
,p_default_value=>'N'
,p_is_translatable=>false
,p_depending_on_attribute_id=>wwv_flow_imp.id(235418815292577052321)
,p_depending_on_has_to_exist=>true
,p_depending_on_condition_type=>'EQUALS'
,p_depending_on_expression=>'Y'
,p_help_text=>'This option enables previewing the downscaled image within a given HTML container element.'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(235418607201138359217)
,p_plugin_id=>wwv_flow_imp.id(235418723369888032539)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>4
,p_display_sequence=>40
,p_prompt=>'Preview Container Selector'
,p_attribute_type=>'TEXT'
,p_is_required=>true
,p_is_translatable=>false
,p_depending_on_attribute_id=>wwv_flow_imp.id(235418877867363065083)
,p_depending_on_has_to_exist=>true
,p_depending_on_condition_type=>'EQUALS'
,p_depending_on_expression=>'Y'
,p_examples=>'.my_element, #MY_ELEMENT'
,p_help_text=>'This option defines the HTML container element which is used to render the image preview. Use an valid jQuery selector'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(226496781661776120868)
,p_plugin_id=>wwv_flow_imp.id(235418723369888032539)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>5
,p_display_sequence=>50
,p_prompt=>'Save Files In'
,p_attribute_type=>'SELECT LIST'
,p_is_required=>true
,p_default_value=>'COLLECTION'
,p_is_translatable=>false
,p_lov_type=>'STATIC'
,p_help_text=>'Either store the uploaded files in an APEX Collection by just providing the collection name or by providing custom PL/SQL code. The latter gives you full control over the saving logic.'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(226496781960463122788)
,p_plugin_attribute_id=>wwv_flow_imp.id(226496781661776120868)
,p_display_sequence=>10
,p_display_value=>'APEX Collection'
,p_return_value=>'COLLECTION'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(226496782435496123892)
,p_plugin_attribute_id=>wwv_flow_imp.id(226496781661776120868)
,p_display_sequence=>20
,p_display_value=>'PL/SQL'
,p_return_value=>'PLSQL'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(226496782838584128271)
,p_plugin_id=>wwv_flow_imp.id(235418723369888032539)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>6
,p_display_sequence=>60
,p_prompt=>'Collection Name'
,p_attribute_type=>'TEXT'
,p_is_required=>true
,p_is_translatable=>false
,p_depending_on_attribute_id=>wwv_flow_imp.id(226496781661776120868)
,p_depending_on_has_to_exist=>true
,p_depending_on_condition_type=>'EQUALS'
,p_depending_on_expression=>'COLLECTION'
,p_examples=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre>',
'select seq_id,',
'       c001    as file_name,',
'       c002    as mime_type,',
'       c003    as file_metadata,',
'       d001    as upload_date,',
'       n001    as file_size,',
'       blob001 as file_content',
'  from apex_collections',
' where collection_name = ''<YOUR_COLLECTION_NAME>''',
'</pre>'))
,p_help_text=>'Enter the name of the APEX Collection storing the uploaded files.'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(235418965096850084768)
,p_plugin_id=>wwv_flow_imp.id(235418723369888032539)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>7
,p_display_sequence=>70
,p_prompt=>'PL/SQL Code'
,p_attribute_type=>'PLSQL'
,p_is_required=>true
,p_is_translatable=>false
,p_depending_on_attribute_id=>wwv_flow_imp.id(226496781661776120868)
,p_depending_on_has_to_exist=>true
,p_depending_on_condition_type=>'EQUALS'
,p_depending_on_expression=>'PLSQL'
,p_examples=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre>',
'declare',
'    l_collection  varchar2( 255 )  := ''FILE_UPLOAD_COLLECTION'';',
'begin',
'    if not apex_collection.collection_exists( p_collection_name => l_collection ) then',
'        apex_collection.create_collection( p_collection_name => l_collection );',
'    end if;',
'',
'    for l_rec_file in ( select aaf.filename,    -- file name',
'                               aaf.mime_type,   -- mime type',
'                               aaf.doc_size,    -- file size in byte',
'                               aaf.blob_content -- file content as blob',
'                          from apex_application_files aaf',
'                         where aaf.name = :APEX$STORAGENAME ) loop',
'      ',
'        apex_collection.add_member(',
'            p_collection_name => l_collection,',
'            p_c001            => l_rec_file.filename,',
'            p_c002            => l_rec_file.mime_type,',
'            p_c003            => :APEX$METADATA,',
'            p_c004            => :P99_ITEM1 || '', '' || :P99_ITEM2,',
'            p_n001            => l_rec_file.doc_size,',
'            p_blob001         => l_rec_file.blob_content',
'        );',
'',
'    end loop;',
'',
'end;',
'</pre>'))
,p_help_text=>'This option defines the PL/SQL Code which is used to process the uploaded files. This can be used to store the files to a given table or collection.'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(235419231651815110575)
,p_plugin_id=>wwv_flow_imp.id(235418723369888032539)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>8
,p_display_sequence=>80
,p_prompt=>'Page Items to Submit'
,p_attribute_type=>'PAGE ITEMS'
,p_is_required=>false
,p_is_translatable=>false
,p_depending_on_attribute_id=>wwv_flow_imp.id(226496781661776120868)
,p_depending_on_has_to_exist=>true
,p_depending_on_condition_type=>'EQUALS'
,p_depending_on_expression=>'PLSQL'
,p_help_text=>'This options defines the page items which will get submitted to the server during file upload. The session state of these items is then available on the server.'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(235438071225656821095)
,p_plugin_id=>wwv_flow_imp.id(235418723369888032539)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>9
,p_display_sequence=>90
,p_prompt=>'Show Processing'
,p_attribute_type=>'CHECKBOX'
,p_is_required=>false
,p_default_value=>'Y'
,p_is_translatable=>false
,p_help_text=>'This option enables a waiting indicator during file upload to show a user that something is processing in the background.'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(226496769894213877700)
,p_plugin_id=>wwv_flow_imp.id(235418723369888032539)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>10
,p_display_sequence=>100
,p_prompt=>'Cancel Uploads using ESC Key'
,p_attribute_type=>'CHECKBOX'
,p_is_required=>false
,p_default_value=>'N'
,p_is_translatable=>false
,p_help_text=>'Should it be possible to cancel file uploads pressing the ESC key? This will only cancel the particular file which is uploaded, if multiple file uploads are configured, the next file will be processed.'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(226496741575657713675)
,p_plugin_id=>wwv_flow_imp.id(235418723369888032539)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>11
,p_display_sequence=>110
,p_prompt=>'File Processing JavaScript Function'
,p_attribute_type=>'JAVASCRIPT'
,p_is_required=>false
,p_is_translatable=>false
,p_examples=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre>',
'async function( file ) {',
'    file._metadata = { "field1": "value1", "field2": "value2" };',
'    return file;',
'}',
'</pre>',
'',
'<pre>',
'async function( file ) {',
'',
'    if ( file.type.startsWith( "image/" ) ) {',
'        file._metadata = await getEXIFMetadata( file );',
'    }',
'',
'    if ( file.type.startsWith( "audio/" ) ) {',
'        const tags = await getAudioMetadata( file );',
'        file._metadata = {',
'            artist: tags.artist,',
'            title: tags.title,',
'            album: tags.album,',
'            year: tags.year',
'        }',
'    }',
'',
'    if ( file.name.toLowerCase().endsWith( ".txt" ) ) {',
'        file._cancel = true;',
'    }',
'',
'    return file;',
'}',
'</pre>'))
,p_help_text=>'Provide an optional async JavaScript function to do file manipulations before the file gets uploaded to the server. To add metadata to a file use <i>file._metadata = {}</i>, this can then be used with the bind variable <i>:APEX$METADATA</i> on the se'
||'rver. To cancel the upload of a given file, just add <i>file._cancel = true</i> flag.'
);
wwv_flow_imp_shared.create_plugin_event(
 p_id=>wwv_flow_imp.id(235437133670628416847)
,p_plugin_id=>wwv_flow_imp.id(235418723369888032539)
,p_name=>'enhancedfileuploadercomplete'
,p_display_name=>'File Upload Complete'
);
wwv_flow_imp_shared.create_plugin_event(
 p_id=>wwv_flow_imp.id(235437133319055416846)
,p_plugin_id=>wwv_flow_imp.id(235418723369888032539)
,p_name=>'enhancedfileuploadererror'
,p_display_name=>'File Upload Error'
);
wwv_flow_imp_shared.create_plugin_event(
 p_id=>wwv_flow_imp.id(226496767246012605890)
,p_plugin_id=>wwv_flow_imp.id(235418723369888032539)
,p_name=>'enhancedfileuploaderfilecancel'
,p_display_name=>'FIle Upload Canceled'
);
wwv_flow_imp_shared.create_plugin_event(
 p_id=>wwv_flow_imp.id(226496628180349856084)
,p_plugin_id=>wwv_flow_imp.id(235418723369888032539)
,p_name=>'enhancedfileuploaderfileprogress'
,p_display_name=>'File Upload Progress'
);
wwv_flow_imp_shared.create_plugin_event(
 p_id=>wwv_flow_imp.id(235437132954064416842)
,p_plugin_id=>wwv_flow_imp.id(235418723369888032539)
,p_name=>'enhancedfileuploadersuccess'
,p_display_name=>'File Upload Success'
);
wwv_flow_imp_shared.create_plugin_event(
 p_id=>wwv_flow_imp.id(226496628556090856085)
,p_plugin_id=>wwv_flow_imp.id(235418723369888032539)
,p_name=>'enhancedfileuploadertotalprogress'
,p_display_name=>'Total Upload Progress'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.4'
,p_default_workspace_id=>4206878434042097
,p_default_application_id=>102
,p_default_id_offset=>178159678296192488844
,p_default_owner=>'TEST'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2F2A210A20436F707972696768742028632920323032322C204F7261636C6520616E642F6F722069747320616666696C69617465732E20416C6C207269676874732072657365727665642E0A202A2F0A282066756E6374696F6E20282064612C20757469';
wwv_flow_imp.g_varchar2_table(2) := '6C2C206974656D2C206576656E742C206D6573736167652C20656E762C2064656275672C20242029207B0A202020202275736520737472696374223B0A0A202020202F2A2A0A20202020202A20496E697469616C697A6174696F6E2066756E6374696F6E';
wwv_flow_imp.g_varchar2_table(3) := '20666F7220456E68616E6365642046696C652055706C6F6164657220444120706C7567696E0A20202020202A0A20202020202A204069676E6F72650A20202020202A2040706172616D207B6F626A6563747D2070416374696F6E0A20202020202A0A2020';
wwv_flow_imp.g_varchar2_table(4) := '2020202A2040706172616D207B6F626A6563747D20704F7074696F6E73205265717569726564206F7074696F6E73206F626A6563742E0A20202020202A2040706172616D207B737472696E677D20704F7074696F6E732E6166666563746564456C656D65';
wwv_flow_imp.g_varchar2_table(5) := '6E740A20202020202A2040706172616D207B626F6F6C65616E7D20704F7074696F6E732E656E61626C65496D616765526573697A650A20202020202A2040706172616D207B6E756D6265727D20704F7074696F6E732E6D6178496D61676553697A650A20';
wwv_flow_imp.g_varchar2_table(6) := '202020202A2040706172616D207B626F6F6C65616E7D20704F7074696F6E732E656E61626C65496D616765507265766965770A20202020202A2040706172616D207B737472696E677D20704F7074696F6E732E70726576696577436F6E7461696E65720A';
wwv_flow_imp.g_varchar2_table(7) := '20202020202A2040706172616D207B61727261797D20704F7074696F6E732E6974656D73546F5375626D69740A20202020202A2040706172616D207B626F6F6C65616E7D20704F7074696F6E732E73686F7750726F63657373696E670A20202020202A20';
wwv_flow_imp.g_varchar2_table(8) := '40706172616D207B737472696E677D20704F7074696F6E732E616A61784964656E7469666965720A20202020202A0A20202020202A2040706172616D207B66756E6374696F6E7D207046696C6550726F63657373696E6746756E6374696F6E0A20202020';
wwv_flow_imp.g_varchar2_table(9) := '202A2F0A2020202064612E656E68616E63656446696C6555706C6F6164203D2066756E6374696F6E20282070416374696F6E2C20704F7074696F6E732C207046696C6550726F63657373696E6746756E6374696F6E2029207B0A2020202020202020636F';
wwv_flow_imp.g_varchar2_table(10) := '6E737420504C5547494E203D2022434F4D2E4F5241434C452E415045582E454E48414E4345445F46494C455F55504C4F41444552222C0A20202020202020202020202020204556454E545F505245464958203D2022656E68616E63656466696C6575706C';
wwv_flow_imp.g_varchar2_table(11) := '6F61646572222C0A20202020202020202020202020204556454E545F414A41585F53554343455353203D204556454E545F505245464958202B202273756363657373222C0A20202020202020202020202020204556454E545F414A41585F4552524F5220';
wwv_flow_imp.g_varchar2_table(12) := '3D204556454E545F505245464958202B20226572726F72222C0A20202020202020202020202020204556454E545F55504C4F41445F434F4D504C455445203D204556454E545F505245464958202B2022636F6D706C657465222C0A202020202020202020';
wwv_flow_imp.g_varchar2_table(13) := '20202020204556454E545F46494C455F43414E43454C203D204556454E545F505245464958202B202266696C6563616E63656C222C0A20202020202020202020202020204556454E545F46494C455F50524F4752455353203D204556454E545F50524546';
wwv_flow_imp.g_varchar2_table(14) := '4958202B202266696C6570726F6772657373222C0A20202020202020202020202020204556454E545F544F54414C5F50524F4752455353203D204556454E545F505245464958202B2022746F74616C70726F6772657373222C0A20202020202020202020';
wwv_flow_imp.g_varchar2_table(15) := '2020202046494C4542524F5753455F434F4E5441494E45525F454C454D454E54203D20226469762E617065782D6974656D2D66696C6564726F70222C0A202020202020202020202020202046494C455F5354415455535F5354415254203D202273746172';
wwv_flow_imp.g_varchar2_table(16) := '74222C0A202020202020202020202020202046494C455F5354415455535F55504C4F4144203D202275706C6F6164222C0A202020202020202020202020202046494C455F5354415455535F53554343455353203D202273756363657373222C0A20202020';
wwv_flow_imp.g_varchar2_table(17) := '2020202020202020202046494C455F5354415455535F4552524F52203D20226572726F72223B0A0A20202020202020206C65742064656661756C744F7074696F6E73203D207B0A2020202020202020202020206166666563746564456C656D656E743A20';
wwv_flow_imp.g_varchar2_table(18) := '22222C0A202020202020202020202020656E61626C65496D616765526573697A653A2066616C73652C0A2020202020202020202020206D6178496D61676553697A653A20313032342C0A202020202020202020202020656E61626C65496D616765507265';
wwv_flow_imp.g_varchar2_table(19) := '766965773A2066616C73652C0A20202020202020202020202070726576696577436F6E7461696E65723A2022222C0A2020202020202020202020206974656D73546F5375626D69743A205B5D2C0A20202020202020202020202073686F7750726F636573';
wwv_flow_imp.g_varchar2_table(20) := '73696E673A20747275652C0A20202020202020202020202063616E63656C576974684573636170653A2066616C73652C0A202020202020202020202020616A61784964656E7469666965723A2022220A20202020202020207D3B0A0A2020202020202020';
wwv_flow_imp.g_varchar2_table(21) := '6C6574206F7074696F6E73203D20242E657874656E6428207B7D2C2064656661756C744F7074696F6E732C20704F7074696F6E7320292C0A2020202020202020202020206974656D4964203D207574696C2E65736361706543535328206F7074696F6E73';
wwv_flow_imp.g_varchar2_table(22) := '2E6166666563746564456C656D656E7420292C0A2020202020202020202020206974656D456C656D203D20646F63756D656E742E676574456C656D656E744279496428206974656D496420292C0A2020202020202020202020206974656D24203D202428';
wwv_flow_imp.g_varchar2_table(23) := '20222322202B206974656D49642C20617065782E6750616765436F6E746578742420292C0A202020202020202020202020616374696F6E203D2070416374696F6E2C0A20202020202020202020202066696C6550726F63657373696E6746756E6374696F';
wwv_flow_imp.g_varchar2_table(24) := '6E203D207046696C6550726F63657373696E6746756E6374696F6E2C0A20202020202020202020202070726F63657373656446696C6573203D205B5D2C0A202020202020202020202020786872526571756573742C0A2020202020202020202020206669';
wwv_flow_imp.g_varchar2_table(25) := '6C65496E666F203D207B7D2C0A20202020202020202020202061626F7274457363617065203D2066616C73652C0A2020202020202020202020207370696E6E6572243B0A0A202020202020202069662028206F7074696F6E732E6974656D73546F537562';
wwv_flow_imp.g_varchar2_table(26) := '6D697420262620747970656F66206F7074696F6E732E6974656D73546F5375626D6974203D3D3D2022737472696E67222029207B0A2020202020202020202020206F7074696F6E732E6974656D73546F5375626D6974203D206F7074696F6E732E697465';
wwv_flow_imp.g_varchar2_table(27) := '6D73546F5375626D69742E73706C69742820222C2220293B0A20202020202020207D0A0A202020202020202064656275672E696E666F2820504C5547494E2C20616374696F6E2C206F7074696F6E732C2066696C6550726F63657373696E6746756E6374';
wwv_flow_imp.g_varchar2_table(28) := '696F6E20293B0A0A20202020202020202F2A2A0A2020202020202020202A20436865636B206966206120676976656E206F626A656374206F72207661726961626C6520697320612066756E6374696F6E0A2020202020202020202A204066756E6374696F';
wwv_flow_imp.g_varchar2_table(29) := '6E20697346756E6374696F6E0A2020202020202020202A2040706172616D207B6F626A6563747D207046756E6374696F6E0A2020202020202020202A204072657475726E207B626F6F6C65616E7D0A2020202020202020202A2F0A202020202020202066';
wwv_flow_imp.g_varchar2_table(30) := '756E6374696F6E20697346756E6374696F6E28207046756E6374696F6E2029207B0A20202020202020202020202072657475726E207046756E6374696F6E20696E7374616E63656F662046756E6374696F6E3B0A20202020202020207D0A0A2020202020';
wwv_flow_imp.g_varchar2_table(31) := '2020202F2A2A0A2020202020202020202A20436865636B206966206120676976656E206F626A656374206F72207661726961626C652069732061206F626A6563740A2020202020202020202A204066756E6374696F6E2069734F626A6563740A20202020';
wwv_flow_imp.g_varchar2_table(32) := '20202020202A2040706172616D207B6F626A6563747D20704F626A6563740A2020202020202020202A204072657475726E207B626F6F6C65616E7D0A2020202020202020202A2F0A202020202020202066756E6374696F6E2069734F626A656374282070';
wwv_flow_imp.g_varchar2_table(33) := '4F626A6563742029207B0A20202020202020202020202072657475726E20704F626A65637420696E7374616E63656F66204F626A6563743B0A20202020202020207D0A0A20202020202020202F2A2A0A2020202020202020202A20436865636B20696620';
wwv_flow_imp.g_varchar2_table(34) := '6120676976656E2066696C6520697320616E20696D6167650A2020202020202020202A204066756E6374696F6E20697346696C65496D6167650A2020202020202020202A2040706172616D207B6F626A6563747D207046696C65206F626A6563740A2020';
wwv_flow_imp.g_varchar2_table(35) := '202020202020202A204072657475726E207B626F6F6C65616E7D0A2020202020202020202A2F0A202020202020202066756E6374696F6E20697346696C65496D61676528207046696C652029207B0A20202020202020202020202072657475726E207046';
wwv_flow_imp.g_varchar2_table(36) := '696C65202626207046696C652E747970652E73706C69742820222F2220295B305D203D3D3D2022696D616765223B0A20202020202020207D0A0A20202020202020202F2A2A0A2020202020202020202A2053686F7720612070726F63657373696E672073';
wwv_flow_imp.g_varchar2_table(37) := '70696E6E65722C20656974686572206F6E207468652066696C652062726F777365206974656D207768656E20737570706F727465642C206F72206F6E2074686520706167650A2020202020202020202A204066756E6374696F6E2073686F775370696E6E';
wwv_flow_imp.g_varchar2_table(38) := '65720A2020202020202020202A2F0A202020202020202066756E6374696F6E2073686F775370696E6E65722829207B0A2020202020202020202020206C65742066696C6542726F777365436F6E7461696E657224203D206974656D242E6E657874282046';
wwv_flow_imp.g_varchar2_table(39) := '494C4542524F5753455F434F4E5441494E45525F454C454D454E5420293B0A0A20202020202020202020202069662028206F7074696F6E732E73686F7750726F63657373696E672029207B0A20202020202020202020202020202020696620282066696C';
wwv_flow_imp.g_varchar2_table(40) := '6542726F777365436F6E7461696E6572242026262066696C6542726F777365436F6E7461696E6572242E6C656E677468203E20302029207B0A202020202020202020202020202020202020202066696C6542726F777365436F6E7461696E6572242E6164';
wwv_flow_imp.g_varchar2_table(41) := '64436C61737328202269732D6C6F6164696E672220293B0A202020202020202020202020202020207D20656C7365207B0A20202020202020202020202020202020202020207370696E6E657224203D207574696C2E73686F775370696E6E657228202428';
wwv_flow_imp.g_varchar2_table(42) := '2022626F647922202920293B0A202020202020202020202020202020207D0A2020202020202020202020207D0A20202020202020207D0A0A20202020202020202F2A2A0A2020202020202020202A2048696465202F2052656D6F7665207468652070726F';
wwv_flow_imp.g_varchar2_table(43) := '63657373696E67207370696E6E65722C20656974686572206F6E207468652066696C652062726F777365206974656D207768656E20737570706F727465642C206F72206F6E2074686520706167650A2020202020202020202A204066756E6374696F6E20';
wwv_flow_imp.g_varchar2_table(44) := '686964655370696E6E65720A2020202020202020202A2F0A202020202020202066756E6374696F6E20686964655370696E6E65722829207B0A2020202020202020202020206C65742066696C6542726F777365436F6E7461696E657224203D206974656D';
wwv_flow_imp.g_varchar2_table(45) := '242E6E657874282046494C4542524F5753455F434F4E5441494E45525F454C454D454E5420293B0A0A20202020202020202020202069662028206F7074696F6E732E73686F7750726F63657373696E672029207B0A202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(46) := '20696620282066696C6542726F777365436F6E7461696E6572242026262066696C6542726F777365436F6E7461696E6572242E6C656E677468203E20302029207B0A2020202020202020202020202020202020202020696620282066696C6542726F7773';
wwv_flow_imp.g_varchar2_table(47) := '65436F6E7461696E6572242E686173436C61737328202269732D6C6F6164696E672220292029207B0A20202020202020202020202020202020202020202020202066696C6542726F777365436F6E7461696E6572242E72656D6F7665436C617373282022';
wwv_flow_imp.g_varchar2_table(48) := '69732D6C6F6164696E672220293B0A20202020202020202020202020202020202020207D0A202020202020202020202020202020207D20656C7365207B0A202020202020202020202020202020202020202069662028207370696E6E6572242026262073';
wwv_flow_imp.g_varchar2_table(49) := '70696E6E6572242E6C656E677468203E20302029207B0A2020202020202020202020202020202020202020202020207370696E6E6572242E72656D6F766528293B0A20202020202020202020202020202020202020207D0A202020202020202020202020';
wwv_flow_imp.g_varchar2_table(50) := '202020207D0A2020202020202020202020207D0A20202020202020207D0A0A20202020202020202F2A2A0A2020202020202020202A20526573697A65206120676976656E20696D61676520746F206D6178202A206D61782064696D656E73696F6E732028';
wwv_flow_imp.g_varchar2_table(51) := '206F7074696F6E732E6D6178496D61676553697A6520290A2020202020202020202A204066756E6374696F6E20726573697A65496D6167650A2020202020202020202A2040706172616D207B6F626A6563747D2070496D61676546696C650A2020202020';
wwv_flow_imp.g_varchar2_table(52) := '202020202A204072657475726E207B50726F6D6973657D0A2020202020202020202A2F0A20202020202020206173796E632066756E6374696F6E20726573697A65496D616765282070496D61676546696C652029207B0A20202020202020202020202072';
wwv_flow_imp.g_varchar2_table(53) := '657475726E206E65772050726F6D697365282028207265736F6C76652029203D3E207B0A20202020202020202020202020202020636F6E7374206D61785769647468203D206F7074696F6E732E6D6178496D61676553697A652C0A202020202020202020';
wwv_flow_imp.g_varchar2_table(54) := '202020202020202020202020206D6178486569676874203D206F7074696F6E732E6D6178496D61676553697A653B0A0A20202020202020202020202020202020696620282070496D61676546696C652029207B0A20202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(55) := '202020206C657420726561646572203D206E65772046696C6552656164657228293B0A0A20202020202020202020202020202020202020202F2F205365742074686520696D61676520666F72207468652046696C655265616465720A2020202020202020';
wwv_flow_imp.g_varchar2_table(56) := '2020202020202020202020207265616465722E6F6E6C6F6164203D2066756E6374696F6E202820652029207B0A2020202020202020202020202020202020202020202020206C657420696D67203D206E657720496D61676528293B0A0A20202020202020';
wwv_flow_imp.g_varchar2_table(57) := '2020202020202020202020202020202020696D672E6F6E6C6F6164203D2066756E6374696F6E202829207B0A202020202020202020202020202020202020202020202020202020202F2F206372656174652063616E7661730A2020202020202020202020';
wwv_flow_imp.g_varchar2_table(58) := '20202020202020202020202020202020206C65742063616E766173203D20646F63756D656E742E637265617465456C656D656E7428202263616E7661732220293B0A202020202020202020202020202020202020202020202020202020206C6574206374';
wwv_flow_imp.g_varchar2_table(59) := '78203D2063616E7661732E676574436F6E7465787428202232642220293B0A202020202020202020202020202020202020202020202020202020206374782E64726177496D6167652820696D672C20302C203020293B0A0A202020202020202020202020';
wwv_flow_imp.g_varchar2_table(60) := '202020202020202020202020202020206C657420696D675769647468203D20696D672E77696474682C0A2020202020202020202020202020202020202020202020202020202020202020696D67486569676874203D20696D672E6865696768742C0A2020';
wwv_flow_imp.g_varchar2_table(61) := '202020202020202020202020202020202020202020202020202020202020726573697A6557696474682C0A2020202020202020202020202020202020202020202020202020202020202020726573697A654865696768743B0A0A20202020202020202020';
wwv_flow_imp.g_varchar2_table(62) := '2020202020202020202020202020202020202F2F2061646420726573697A696E67206C6F6769630A202020202020202020202020202020202020202020202020202020206966202820696D675769647468203E20696D674865696768742029207B0A2020';
wwv_flow_imp.g_varchar2_table(63) := '202020202020202020202020202020202020202020202020202020202020726573697A655769647468203D20696D675769647468203E206D61785769647468203F206D61785769647468203A20696D6757696474683B0A20202020202020202020202020';
wwv_flow_imp.g_varchar2_table(64) := '20202020202020202020202020202020202020726573697A65486569676874203D20696D675769647468203E206D61785769647468203F20696D67486569676874202A2028206D61785769647468202F20696D6757696474682029203A20696D67486569';
wwv_flow_imp.g_varchar2_table(65) := '676874202A202820696D675769647468202F206D6178576964746820293B0A202020202020202020202020202020202020202020202020202020207D20656C7365207B0A2020202020202020202020202020202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(66) := '726573697A65486569676874203D20696D67486569676874203E206D6178486569676874203F206D6178486569676874203A20696D674865696768743B0A2020202020202020202020202020202020202020202020202020202020202020726573697A65';
wwv_flow_imp.g_varchar2_table(67) := '5769647468203D20696D67486569676874203E206D6178486569676874203F20696D675769647468202A2028206D6178486569676874202F20696D674865696768742029203A20696D675769647468202A202820696D67486569676874202F206D617848';
wwv_flow_imp.g_varchar2_table(68) := '656967687420293B0A202020202020202020202020202020202020202020202020202020207D0A0A202020202020202020202020202020202020202020202020202020202F2F20737065636966792074686520726573697A696E6720726573756C740A20';
wwv_flow_imp.g_varchar2_table(69) := '20202020202020202020202020202020202020202020202020202063616E7661732E7769647468203D20726573697A6557696474683B0A2020202020202020202020202020202020202020202020202020202063616E7661732E686569676874203D2072';
wwv_flow_imp.g_varchar2_table(70) := '6573697A654865696768743B0A0A20202020202020202020202020202020202020202020202020202020637478203D2063616E7661732E676574436F6E7465787428202232642220293B0A20202020202020202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(71) := '2020206374782E64726177496D6167652820696D672C20302C20302C20726573697A6557696474682C20726573697A6548656967687420293B0A0A202020202020202020202020202020202020202020202020202020202F2F2072657475726E20746865';
wwv_flow_imp.g_varchar2_table(72) := '20726573697A656420626C6F6220617320612066696C65206F626A6563740A2020202020202020202020202020202020202020202020202020202063616E7661732E746F426C6F62280A2020202020202020202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(73) := '20202020202066756E6374696F6E202820626C6F622029207B0A2020202020202020202020202020202020202020202020202020202020202020202020207265736F6C766528206E65772046696C6528205B626C6F625D2C2070496D61676546696C652E';
wwv_flow_imp.g_varchar2_table(74) := '6E616D652C207B20747970653A2070496D61676546696C652E747970652C206C6173744D6F6469666965643A206E6577204461746528292E67657454696D652829207D202920293B0A202020202020202020202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(75) := '20202020207D2C0A202020202020202020202020202020202020202020202020202020202020202070496D61676546696C652E747970652C0A2020202020202020202020202020202020202020202020202020202020202020302E38350A202020202020';
wwv_flow_imp.g_varchar2_table(76) := '20202020202020202020202020202020202020202020293B0A2020202020202020202020202020202020202020202020207D3B0A202020202020202020202020202020202020202020202020696D672E737263203D20652E7461726765742E726573756C';
wwv_flow_imp.g_varchar2_table(77) := '743B0A20202020202020202020202020202020202020207D3B0A20202020202020202020202020202020202020207265616465722E7265616441734461746155524C282070496D61676546696C6520293B0A202020202020202020202020202020207D0A';
wwv_flow_imp.g_varchar2_table(78) := '2020202020202020202020207D20293B0A20202020202020207D0A0A20202020202020202F2A2A0A2020202020202020202A2052656E64657273206120676976656E20696D6167652066696C6520746F206120646566696E656420636F6E7461696E6572';
wwv_flow_imp.g_varchar2_table(79) := '20444F4D20656C656D656E740A2020202020202020202A204066756E6374696F6E2072656E646572496D616765507265766965770A2020202020202020202A2040706172616D207B6F626A6563747D207046696C650A2020202020202020202A2F0A2020';
wwv_flow_imp.g_varchar2_table(80) := '20202020202066756E6374696F6E2072656E646572496D6167655072657669657728207046696C652029207B0A2020202020202020202020206C65742070726576696577436F6E7461696E657224203D202428206F7074696F6E732E7072657669657743';
wwv_flow_imp.g_varchar2_table(81) := '6F6E7461696E65722C20617065782E6750616765436F6E746578742420293B0A0A202020202020202020202020696620282070726576696577436F6E7461696E6572242E70726F702820227461674E616D65222029203D3D3D2022494D47222029207B0A';
wwv_flow_imp.g_varchar2_table(82) := '2020202020202020202020202020202070726576696577436F6E7461696E6572242E61747472282022737263222C2055524C2E6372656174654F626A65637455524C28207046696C65202920293B0A2020202020202020202020207D20656C7365207B0A';
wwv_flow_imp.g_varchar2_table(83) := '2020202020202020202020202020202070726576696577436F6E7461696E6572242E70726570656E642820242820223C696D673E222C207B207372633A2055524C2E6372656174654F626A65637455524C28207046696C652029207D202920293B0A2020';
wwv_flow_imp.g_varchar2_table(84) := '202020202020202020207D0A20202020202020207D0A0A20202020202020202F2A2A0A2020202020202020202A204765742074686520746F74616C2073697A65206F6620616C6C2066696C6573206F6620616E2075706C6F616420616374696F6E0A2020';
wwv_flow_imp.g_varchar2_table(85) := '202020202020202A204066756E6374696F6E20676574546F74616C46696C657353697A650A2020202020202020202A204072657475726E207B6E756D6265727D0A2020202020202020202A2F0A202020202020202066756E6374696F6E20676574546F74';
wwv_flow_imp.g_varchar2_table(86) := '616C46696C657353697A652829207B0A2020202020202020202020206C65742066696C6573203D206974656D456C656D2E66696C65732C0A20202020202020202020202020202020746F74616C53697A65203D20303B0A0A202020202020202020202020';
wwv_flow_imp.g_varchar2_table(87) := '666F722028206C65742069203D20303B2069203C2066696C65732E6C656E6774683B20692B2B2029207B0A202020202020202020202020202020206C65742066696C65203D2066696C65735B695D2C0A2020202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(88) := '70726F63657373656446696C65203D2070726F63657373656446696C65735B70726F63657373656446696C65732E66696E64496E646578282028206F626A2029203D3E206F626A2E66696C652E6E616D65203D3D3D2066696C652E6E616D6520295D3B0A';
wwv_flow_imp.g_varchar2_table(89) := '0A202020202020202020202020202020206966202820697346696C65496D616765282066696C6520292026262070726F63657373656446696C652026262070726F63657373656446696C652E66696C652026262070726F63657373656446696C652E6669';
wwv_flow_imp.g_varchar2_table(90) := '6C652E73697A65203C2066696C652E73697A652029207B0A2020202020202020202020202020202020202020746F74616C53697A65202B3D2070726F63657373656446696C652E66696C652E73697A65207C7C20303B0A20202020202020202020202020';
wwv_flow_imp.g_varchar2_table(91) := '2020207D20656C7365207B0A2020202020202020202020202020202020202020746F74616C53697A65202B3D2066696C652E73697A65207C7C20303B0A202020202020202020202020202020207D0A2020202020202020202020207D0A0A202020202020';
wwv_flow_imp.g_varchar2_table(92) := '20202020202072657475726E20746F74616C53697A653B0A20202020202020207D0A0A20202020202020202F2A2A0A2020202020202020202A20476574207468652073697A65206F6620616C6C2066696C65732077686963682061726520616C72656164';
wwv_flow_imp.g_varchar2_table(93) := '792070726F63657373656420616E642075706C6F616465640A2020202020202020202A204066756E6374696F6E2067657450726F63657373656446696C657353697A650A2020202020202020202A204072657475726E207B6E756D6265727D0A20202020';
wwv_flow_imp.g_varchar2_table(94) := '20202020202A2F0A202020202020202066756E6374696F6E2067657450726F63657373656446696C657353697A652829207B0A2020202020202020202020206C65742070726F63657373656453697A65203D20303B0A0A20202020202020202020202066';
wwv_flow_imp.g_varchar2_table(95) := '6F722028206C65742069203D20303B2069203C2070726F63657373656446696C65732E6C656E6774683B20692B2B2029207B0A2020202020202020202020202020202069662028205B46494C455F5354415455535F535543434553532C2046494C455F53';
wwv_flow_imp.g_varchar2_table(96) := '54415455535F4552524F525D2E696E636C75646573282070726F63657373656446696C65735B695D2E73746174757320292029207B0A202020202020202020202020202020202020202070726F63657373656453697A65202B3D2070726F636573736564';
wwv_flow_imp.g_varchar2_table(97) := '46696C65735B695D2E66696C652E73697A65207C7C20303B0A202020202020202020202020202020207D0A2020202020202020202020207D0A0A20202020202020202020202072657475726E2070726F63657373656453697A653B0A2020202020202020';
wwv_flow_imp.g_varchar2_table(98) := '7D0A0A20202020202020202F2A2A0A2020202020202020202A2053686F777320616E206572726F72206E6F74696669636174696F6E207573696E6720617065782E6D6573736167652E73686F774572726F72730A2020202020202020202A204066756E63';
wwv_flow_imp.g_varchar2_table(99) := '74696F6E2073686F774572726F720A2020202020202020202A2040706172616D207B737472696E677D20704572726F724D6573736167650A2020202020202020202A2F0A202020202020202066756E6374696F6E2073686F774572726F72282070457272';
wwv_flow_imp.g_varchar2_table(100) := '6F724D6573736167652029207B0A2020202020202020202020206D6573736167652E636C6561724572726F727328293B0A2020202020202020202020206D6573736167652E73686F774572726F727328205B0A202020202020202020202020202020207B';
wwv_flow_imp.g_varchar2_table(101) := '0A2020202020202020202020202020202020202020747970653A20226572726F72222C0A20202020202020202020202020202020202020206C6F636174696F6E3A205B2270616765225D2C0A202020202020202020202020202020202020202070616765';
wwv_flow_imp.g_varchar2_table(102) := '4974656D3A206974656D49642C0A20202020202020202020202020202020202020206D6573736167653A20704572726F724D6573736167652C0A2020202020202020202020202020202020202020756E736166653A2066616C73650A2020202020202020';
wwv_flow_imp.g_varchar2_table(103) := '20202020202020207D0A2020202020202020202020205D20293B0A20202020202020207D0A0A20202020202020202F2A2A0A2020202020202020202A204D616B657320616E20466F726D4461746120414A4158207265717565737420746F207468652044';
wwv_flow_imp.g_varchar2_table(104) := '42207365727665722075706C6F6164696E67206120706172746963756C61722066696C650A2020202020202020202A204066756E6374696F6E206D616B65466F726D44617461526571756573740A2020202020202020202A2040706172616D207B6F626A';
wwv_flow_imp.g_varchar2_table(105) := '6563747D2070466F726D446174610A2020202020202020202A2040706172616D207B6F626A6563747D207046696C650A2020202020202020202A204072657475726E207B6F626A6563747D0A2020202020202020202A2F0A20202020202020206173796E';
wwv_flow_imp.g_varchar2_table(106) := '632066756E6374696F6E206D616B65466F726D4461746152657175657374282070466F726D446174612C207046696C652029207B0A202020202020202020202020636F6E737420746F74616C46696C657353697A65203D20676574546F74616C46696C65';
wwv_flow_imp.g_varchar2_table(107) := '7353697A6528292C0A20202020202020202020202020202020202070726F63657373656446696C657353697A65203D2067657450726F63657373656446696C657353697A6528293B0A0A20202020202020202020202070726F63657373656446696C6573';
wwv_flow_imp.g_varchar2_table(108) := '5B70726F63657373656446696C65732E66696E64496E646578282028206F626A2029203D3E206F626A2E66696C652E6E616D65203D3D3D207046696C652E6E616D6520295D2E737461747573203D2046494C455F5354415455535F55504C4F41443B0A0A';
wwv_flow_imp.g_varchar2_table(109) := '202020202020202020202020747279207B0A20202020202020202020202020202020636F6E737420726573706F6E7365203D20617761697420242E616A617828207B0A2020202020202020202020202020202020202020747970653A2022504F5354222C';
wwv_flow_imp.g_varchar2_table(110) := '0A202020202020202020202020202020202020202075726C3A20227777765F666C6F772E616A6178222C0A202020202020202020202020202020202020202064617461547970653A20226A736F6E222C0A20202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(111) := '2070726F63657373446174613A2066616C73652C0A2020202020202020202020202020202020202020636F6E74656E74547970653A2066616C73652C0A2020202020202020202020202020202020202020646174613A2070466F726D446174612C0A2020';
wwv_flow_imp.g_varchar2_table(112) := '2020202020202020202020202020202020202F2F207868722066756E6374696F6E20666F722066696C652075706C6F61642070726F6772657373206576656E7420737570706F72740A20202020202020202020202020202020202020207868723A206675';
wwv_flow_imp.g_varchar2_table(113) := '6E6374696F6E202829207B0A20202020202020202020202020202020202020202020202078687252657175657374203D20242E616A617853657474696E67732E78687228293B0A0A20202020202020202020202020202020202020202020202078687252';
wwv_flow_imp.g_varchar2_table(114) := '6571756573742E75706C6F61642E6F6E70726F6772657373203D2066756E6374696F6E202820652029207B0A202020202020202020202020202020202020202020202020202020206966202820652E6C656E677468436F6D70757461626C652029207B0A';
wwv_flow_imp.g_varchar2_table(115) := '20202020202020202020202020202020202020202020202020202020202020206576656E742E7472696767657228206974656D242C204556454E545F46494C455F50524F47524553532C207B0A2020202020202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(116) := '202020202020202020202020206E616D653A207046696C652E6E616D652C0A202020202020202020202020202020202020202020202020202020202020202020202020747970653A207046696C652E747970652C0A202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(117) := '20202020202020202020202020202020202020202073697A653A207046696C652E73697A652C0A20202020202020202020202020202020202020202020202020202020202020202020202070726F67726573733A202820652E6C6F61646564202F20652E';
wwv_flow_imp.g_varchar2_table(118) := '746F74616C2029202A203130302C0A2020202020202020202020202020202020202020202020202020202020202020202020206C6F616465643A20652E6C6F616465642C0A20202020202020202020202020202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(119) := '2020202020746F74616C3A20652E746F74616C0A20202020202020202020202020202020202020202020202020202020202020207D20293B0A0A20202020202020202020202020202020202020202020202020202020202020206C657420746F74616C50';
wwv_flow_imp.g_varchar2_table(120) := '726F6772657373203D202820282070726F63657373656446696C657353697A65202B20652E6C6F616465642029202F20746F74616C46696C657353697A652029202A203130303B0A0A202020202020202020202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(121) := '20202020206576656E742E7472696767657228206974656D242C204556454E545F544F54414C5F50524F47524553532C207B0A20202020202020202020202020202020202020202020202020202020202020202020202070726F67726573733A20746F74';
wwv_flow_imp.g_varchar2_table(122) := '616C50726F6772657373203E20313030203F20313030203A20746F74616C50726F67726573732C0A2020202020202020202020202020202020202020202020202020202020202020202020206C6F616465643A2070726F63657373656446696C65735369';
wwv_flow_imp.g_varchar2_table(123) := '7A65202B20652E6C6F61646564203E20746F74616C46696C657353697A65203F20746F74616C46696C657353697A65203A2070726F63657373656446696C657353697A65202B20652E6C6F616465642C0A20202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(124) := '2020202020202020202020202020202020746F74616C3A20746F74616C46696C657353697A650A20202020202020202020202020202020202020202020202020202020202020207D20293B0A202020202020202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(125) := '202020207D0A2020202020202020202020202020202020202020202020207D3B0A0A20202020202020202020202020202020202020202020202072657475726E20786872526571756573743B0A20202020202020202020202020202020202020207D0A20';
wwv_flow_imp.g_varchar2_table(126) := '2020202020202020202020202020207D20293B0A0A2020202020202020202020202020202072657475726E20726573706F6E73653B0A2020202020202020202020207D2063617463682028206572726F722029207B0A2020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(127) := '2020696620282061626F72744573636170652029207B0A202020202020202020202020202020202020202061626F7274457363617065203D2066616C73653B0A202020202020202020202020202020202020202072657475726E207B2073756363657373';
wwv_flow_imp.g_varchar2_table(128) := '3A2074727565207D3B0A202020202020202020202020202020207D0A0A2020202020202020202020202020202072657475726E207B20737563636573733A2066616C73652C206572726F723A206572726F72207D3B0A2020202020202020202020207D0A';
wwv_flow_imp.g_varchar2_table(129) := '20202020202020207D0A0A20202020202020202F2A2A0A2020202020202020202A205772617070696E672066756E6374696F6E20746F2075706C6F616420612073696E676C652066696C65207573696E6720414A41582E2048657265207765206275696C';
wwv_flow_imp.g_varchar2_table(130) := '642074686520466F726D44617461206F626A65637420616E642063616C6C2074686520726571756573742066756E6374696F6E0A2020202020202020202A204066756E6374696F6E2075706C6F616446696C650A2020202020202020202A204070617261';
wwv_flow_imp.g_varchar2_table(131) := '6D207B6F626A6563747D207046696C650A2020202020202020202A204072657475726E207B6F626A6563747D0A2020202020202020202A2F0A20202020202020206173796E632066756E6374696F6E2075706C6F616446696C6528207046696C65202920';
wwv_flow_imp.g_varchar2_table(132) := '7B0A2020202020202020202020206C657420666F726D44617461203D206E657720466F726D4461746128292C0A20202020202020202020202020202020726573756C743B0A0A202020202020202020202020666F726D446174612E617070656E64282022';
wwv_flow_imp.g_varchar2_table(133) := '705F72657175657374222C2022504C5547494E3D22202B206F7074696F6E732E616A61784964656E74696669657220293B0A202020202020202020202020666F726D446174612E617070656E64282022705F666C6F775F6964222C20656E762E4150505F';
wwv_flow_imp.g_varchar2_table(134) := '494420293B0A202020202020202020202020666F726D446174612E617070656E64282022705F666C6F775F737465705F6964222C20656E762E4150505F504147455F494420293B0A202020202020202020202020666F726D446174612E617070656E6428';
wwv_flow_imp.g_varchar2_table(135) := '2022705F696E7374616E6365222C20656E762E4150505F53455353494F4E20293B0A202020202020202020202020666F726D446174612E617070656E64282022705F6465627567222C20247628202270646562756722202920293B0A2020202020202020';
wwv_flow_imp.g_varchar2_table(136) := '20202020666F726D446174612E617070656E64282022463031222C207046696C652C207046696C652E6E616D6520293B0A202020202020202020202020666F726D446174612E617070656E64282022583031222C207046696C652E6E616D6520293B0A20';
wwv_flow_imp.g_varchar2_table(137) := '2020202020202020202020666F726D446174612E617070656E64282022583032222C207046696C652E7479706520293B0A0A20202020202020202020202069662028207046696C652E5F6D657461646174612026262069734F626A65637428207046696C';
wwv_flow_imp.g_varchar2_table(138) := '652E5F6D6574616461746120292029207B0A20202020202020202020202020202020666F726D446174612E617070656E64282022583033222C204A534F4E2E737472696E6769667928207046696C652E5F6D65746164617461202920293B0A2020202020';
wwv_flow_imp.g_varchar2_table(139) := '202020202020207D0A0A202020202020202020202020666F722028206C65742069203D20303B2069203C206F7074696F6E732E6974656D73546F5375626D69742E6C656E6774683B20692B2B2029207B0A20202020202020202020202020202020666F72';
wwv_flow_imp.g_varchar2_table(140) := '6D446174612E617070656E64282022705F6172675F6E616D6573222C206F7074696F6E732E6974656D73546F5375626D69745B695D20293B0A2020202020202020202020207D0A202020202020202020202020666F722028206C65742069203D20303B20';
wwv_flow_imp.g_varchar2_table(141) := '69203C206F7074696F6E732E6974656D73546F5375626D69742E6C656E6774683B20692B2B2029207B0A20202020202020202020202020202020666F726D446174612E617070656E64282022705F6172675F76616C756573222C206974656D28206F7074';
wwv_flow_imp.g_varchar2_table(142) := '696F6E732E6974656D73546F5375626D69745B695D20292E67657456616C7565282920293B0A2020202020202020202020207D0A0A202020202020202020202020726573756C74203D206177616974206D616B65466F726D446174615265717565737428';
wwv_flow_imp.g_varchar2_table(143) := '20666F726D446174612C207046696C6520293B0A0A20202020202020202020202072657475726E20726573756C743B0A20202020202020207D0A0A20202020202020202F2A2A0A2020202020202020202A204D61696E2066756E6374696F6E2077686963';
wwv_flow_imp.g_varchar2_table(144) := '682068616E646C6573207468652070726F63657373696E67206F6620616C6C2066696C6573206F6620616E2066696C652062726F777365206974656D0A2020202020202020202A204066756E6374696F6E2070726F6365737346696C65730A2020202020';
wwv_flow_imp.g_varchar2_table(145) := '202020202A2040706172616D207B61727261797D207046696C65730A2020202020202020202A2040706172616D207B66756E6374696F6E7D2063616C6C6261636B0A2020202020202020202A2F0A20202020202020206173796E632066756E6374696F6E';
wwv_flow_imp.g_varchar2_table(146) := '2070726F6365737346696C657328207046696C65732C2063616C6C6261636B2029207B0A2020202020202020202020206C657420726573756C742C0A202020202020202020202020202020206861734572726F72203D2066616C73653B0A0A2020202020';
wwv_flow_imp.g_varchar2_table(147) := '2020202020202070726F63657373656446696C6573203D205B5D3B0A0A202020202020202020202020666F722028206C65742069203D20303B2069203C207046696C65732E6C656E6774683B20692B2B2029207B0A202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(148) := '206C65742066696C65203D207046696C65735B695D2C0A202020202020202020202020202020202020202066696C654D65746164617461203D207B7D3B0A0A202020202020202020202020202020202F2F20616C6C2066696C65732073686F756C642068';
wwv_flow_imp.g_varchar2_table(149) := '61766520612076616C6964206D696D6520747970650A2020202020202020202020202020202069662028202166696C652E747970652029207B0A202020202020202020202020202020202020202066696C65203D206E65772046696C6528205B66696C65';
wwv_flow_imp.g_varchar2_table(150) := '5D2C2066696C652E6E616D652C207B20747970653A20226170706C69636174696F6E2F6F637465742D73747265616D222C206C6173744D6F6469666965643A206E6577204461746528292E67657454696D652829207D20293B0A20202020202020202020';
wwv_flow_imp.g_varchar2_table(151) := '2020202020207D0A0A202020202020202020202020202020202F2F206966206120646576656C6F70657220686173207370656369666965642061206F7074696F6E616C2066696C652070726F63657373696E67202F206D616E6970756C6174696F6E2066';
wwv_flow_imp.g_varchar2_table(152) := '756E6374696F6E207765206578656375746520697420686572650A202020202020202020202020202020202F2F20626573696465206D616E6970756C6174696E67207468652066696C6520697473656C662C20646576732063616E206164642066696C65';
wwv_flow_imp.g_varchar2_table(153) := '2E5F6D6574616461746120616E642066696C652E5F63616E63656C20746F2063616E63656C207468652075706C6F6164206F6620746869732066696C650A20202020202020202020202020202020696620282066696C6550726F63657373696E6746756E';
wwv_flow_imp.g_varchar2_table(154) := '6374696F6E20262620697346756E6374696F6E282066696C6550726F63657373696E6746756E6374696F6E20292029207B0A202020202020202020202020202020202020202066696C65203D2061776169742066696C6550726F63657373696E6746756E';
wwv_flow_imp.g_varchar2_table(155) := '6374696F6E282066696C6520293B0A0A202020202020202020202020202020202020202066696C654D65746164617461203D2066696C652E5F6D657461646174613B0A0A2020202020202020202020202020202020202020696620282066696C652E5F63';
wwv_flow_imp.g_varchar2_table(156) := '616E63656C2029207B0A2020202020202020202020202020202020202020202020206576656E742E7472696767657228206974656D242C204556454E545F46494C455F43414E43454C2C207B206E616D653A2066696C652E6E616D652C20747970653A20';
wwv_flow_imp.g_varchar2_table(157) := '66696C652E747970652C2073697A653A2066696C652E73697A65207D20293B0A202020202020202020202020202020202020202020202020636F6E74696E75653B0A20202020202020202020202020202020202020207D0A202020202020202020202020';
wwv_flow_imp.g_varchar2_table(158) := '202020207D0A0A202020202020202020202020202020202F2F20696620696D61676520726573697A696E6720697320656E61626C65642077652065786563757465206F7572206C6F67696320616E64206F7074696F6E616C6C792072656E646572206120';
wwv_flow_imp.g_varchar2_table(159) := '696D61676520707265766965770A2020202020202020202020202020202069662028206F7074696F6E732E656E61626C65496D616765526573697A6520262620697346696C65496D616765282066696C6520292029207B0A202020202020202020202020';
wwv_flow_imp.g_varchar2_table(160) := '202020202020202066696C65203D20617761697420726573697A65496D616765282066696C6520293B0A0A202020202020202020202020202020202020202069662028206F7074696F6E732E656E61626C65496D616765507265766965772029207B0A20';
wwv_flow_imp.g_varchar2_table(161) := '202020202020202020202020202020202020202020202072656E646572496D61676550726576696577282066696C6520293B0A20202020202020202020202020202020202020207D0A202020202020202020202020202020207D0A0A2020202020202020';
wwv_flow_imp.g_varchar2_table(162) := '20202020202020202F2F2069662066696C652E5F6D65746164617461206973206C6F73742C20652E672E20627920696D61676520726573697A696E672C2077652061646420697420616761696E0A20202020202020202020202020202020696620282021';
wwv_flow_imp.g_varchar2_table(163) := '66696C652E5F6D657461646174612029207B0A202020202020202020202020202020202020202066696C652E5F6D65746164617461203D2066696C654D65746164617461207C7C207B7D3B0A202020202020202020202020202020207D0A0A2020202020';
wwv_flow_imp.g_varchar2_table(164) := '20202020202020202020202F2F206275696C64206120676C6F62616C2066696C65496E666F206F626A6563742077686963682063616E2062652075736564206F757473696465206F6620746869732070726F63657373696E672066756E6374696F6E0A20';
wwv_flow_imp.g_varchar2_table(165) := '2020202020202020202020202020202F2F20616E6420776974686F7574206C65616B696E67207468652077686F6C652066696C650A2020202020202020202020202020202066696C65496E666F203D207B0A202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(166) := '20206E616D653A2066696C652E6E616D652C0A2020202020202020202020202020202020202020747970653A2066696C652E747970652C0A202020202020202020202020202020202020202073697A653A2066696C652E73697A650A2020202020202020';
wwv_flow_imp.g_varchar2_table(167) := '20202020202020207D3B0A0A202020202020202020202020202020202F2F206E6F772075706C6F6164207468652066696C650A2020202020202020202020202020202070726F63657373656446696C65732E7075736828207B2066696C653A2066696C65';
wwv_flow_imp.g_varchar2_table(168) := '2C207374617475733A2046494C455F5354415455535F5354415254207D20293B0A0A20202020202020202020202020202020726573756C74203D2061776169742075706C6F616446696C65282066696C6520293B0A0A2020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(169) := '20206966202820726573756C742E737563636573732029207B0A202020202020202020202020202020202020202070726F63657373656446696C65735B70726F63657373656446696C65732E66696E64496E646578282028206F626A2029203D3E206F62';
wwv_flow_imp.g_varchar2_table(170) := '6A2E66696C652E6E616D65203D3D3D2066696C652E6E616D6520295D2E737461747573203D2046494C455F5354415455535F535543434553533B0A20202020202020202020202020202020202020206576656E742E7472696767657228206974656D242C';
wwv_flow_imp.g_varchar2_table(171) := '204556454E545F414A41585F535543434553532C207B206E616D653A2066696C652E6E616D652C20747970653A2066696C652E747970652C2073697A653A2066696C652E73697A65207D20293B0A202020202020202020202020202020207D20656C7365';
wwv_flow_imp.g_varchar2_table(172) := '207B0A202020202020202020202020202020202020202070726F63657373656446696C65735B70726F63657373656446696C65732E66696E64496E646578282028206F626A2029203D3E206F626A2E66696C652E6E616D65203D3D3D2066696C652E6E61';
wwv_flow_imp.g_varchar2_table(173) := '6D6520295D2E737461747573203D2046494C455F5354415455535F4552524F523B0A20202020202020202020202020202020202020206576656E742E7472696767657228206974656D242C204556454E545F414A41585F4552524F522C207B206E616D65';
wwv_flow_imp.g_varchar2_table(174) := '3A2066696C652E6E616D652C20747970653A2066696C652E747970652C2073697A653A2066696C652E73697A652C206572726F723A20726573756C742E6572726F72207D20293B0A202020202020202020202020202020202020202073686F774572726F';
wwv_flow_imp.g_varchar2_table(175) := '722820726573756C742E6572726F722E7374617475735465787420293B0A0A20202020202020202020202020202020202020206966202820216861734572726F722029207B0A202020202020202020202020202020202020202020202020686173457272';
wwv_flow_imp.g_varchar2_table(176) := '6F72203D20747275653B0A20202020202020202020202020202020202020207D0A202020202020202020202020202020207D0A0A2020202020202020202020202020202064656275672E696E666F2820504C5547494E2C2066696C652E6E616D652C2072';
wwv_flow_imp.g_varchar2_table(177) := '6573756C7420293B0A2020202020202020202020207D0A20202020202020202020202063616C6C6261636B28206861734572726F7220293B0A20202020202020207D0A0A20202020202020202F2F2069662063616E63656C207769746820657363206B65';
wwv_flow_imp.g_varchar2_table(178) := '7920697320656E61626C6564207765206164642061206576656E74206C697374656E657220666F7220746861740A202020202020202069662028206F7074696F6E732E63616E63656C576974684573636170652029207B0A202020202020202020202020';
wwv_flow_imp.g_varchar2_table(179) := '242820646F63756D656E7420292E6B65797570282066756E6374696F6E202820652029207B0A202020202020202020202020202020206966202820652E6B6579203D3D3D2022457363617065222029207B0A202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(180) := '20206966202820786872526571756573742029207B0A2020202020202020202020202020202020202020202020206576656E742E7472696767657228206974656D242C204556454E545F46494C455F43414E43454C2C2066696C65496E666F20293B0A20';
wwv_flow_imp.g_varchar2_table(181) := '202020202020202020202020202020202020202020202061626F7274457363617065203D20747275653B0A202020202020202020202020202020202020202020202020786872526571756573742E61626F727428293B0A20202020202020202020202020';
wwv_flow_imp.g_varchar2_table(182) := '202020202020207D0A202020202020202020202020202020207D0A2020202020202020202020207D20293B0A20202020202020207D0A0A20202020202020202F2F2069662066696C6573206172652070726573656E74206F6E207468652066696C652062';
wwv_flow_imp.g_varchar2_table(183) := '726F777365206974656D2077652073746172742070726F63657373696E67207468652075706C6F6164730A202020202020202069662028206974656D456C656D2E66696C6573202626206974656D456C656D2E66696C65732E6C656E677468203E203020';
wwv_flow_imp.g_varchar2_table(184) := '29207B0A20202020202020202020202073686F775370696E6E657228293B0A0A20202020202020202020202070726F6365737346696C657328206974656D456C656D2E66696C65732C2066756E6374696F6E2028206572726F724F636375727265642029';
wwv_flow_imp.g_varchar2_table(185) := '207B0A20202020202020202020202020202020686964655370696E6E657228293B0A0A202020202020202020202020202020206576656E742E7472696767657228206974656D242C204556454E545F55504C4F41445F434F4D504C45544520293B0A2020';
wwv_flow_imp.g_varchar2_table(186) := '20202020202020202020202020206974656D242E76616C2820222220292E6368616E676528293B0A0A2020202020202020202020202020202064612E726573756D652820616374696F6E2E726573756D6543616C6C6261636B2C206572726F724F636375';
wwv_flow_imp.g_varchar2_table(187) := '7272656420293B0A2020202020202020202020207D20293B0A20202020202020207D0A202020207D3B0A7D20292820617065782E64612C20617065782E7574696C2C20617065782E6974656D2C20617065782E6576656E742C20617065782E6D65737361';
wwv_flow_imp.g_varchar2_table(188) := '67652C20617065782E656E762C20617065782E64656275672C20617065782E6A517565727920293B0A';
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.4'
,p_default_workspace_id=>4206878434042097
,p_default_application_id=>102
,p_default_id_offset=>178159678296192488844
,p_default_owner=>'TEST'
);
wwv_flow_imp_shared.create_plugin_file(
 p_id=>wwv_flow_imp.id(226496793803728973990)
,p_plugin_id=>wwv_flow_imp.id(235418723369888032539)
,p_file_name=>'enhancedFileUpload.js'
,p_mime_type=>'application/javascript'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.4'
,p_default_workspace_id=>4206878434042097
,p_default_application_id=>102
,p_default_id_offset=>178159678296192488844
,p_default_owner=>'TEST'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2866756E6374696F6E28652C742C612C6E2C692C732C722C6F297B2275736520737472696374223B652E656E68616E63656446696C6555706C6F61643D66756E6374696F6E286C2C702C63297B66756E6374696F6E206D2865297B72657475726E206520';
wwv_flow_imp.g_varchar2_table(2) := '696E7374616E63656F662046756E6374696F6E7D66756E6374696F6E20642865297B72657475726E206520696E7374616E63656F66204F626A6563747D66756E6374696F6E20752865297B72657475726E2065262622696D616765223D3D3D652E747970';
wwv_flow_imp.g_varchar2_table(3) := '652E73706C697428222F22295B305D7D66756E6374696F6E206728297B6C657420653D242E6E6578742841293B582E73686F7750726F63657373696E67262628652626652E6C656E6774683E303F652E616464436C617373282269732D6C6F6164696E67';
wwv_flow_imp.g_varchar2_table(4) := '22293A4E3D742E73686F775370696E6E6572286F2822626F6479222929297D66756E6374696F6E206628297B6C657420653D242E6E6578742841293B582E73686F7750726F63657373696E67262628652626652E6C656E6774683E303F652E686173436C';
wwv_flow_imp.g_varchar2_table(5) := '617373282269732D6C6F6164696E6722292626652E72656D6F7665436C617373282269732D6C6F6164696E6722293A4E26264E2E6C656E6774683E3026264E2E72656D6F76652829297D6173796E632066756E6374696F6E20782865297B72657475726E';
wwv_flow_imp.g_varchar2_table(6) := '206E65772050726F6D69736528743D3E7B636F6E737420613D582E6D6178496D61676553697A652C6E3D582E6D6178496D61676553697A653B69662865297B6C657420693D6E65772046696C655265616465723B692E6F6E6C6F61643D66756E6374696F';
wwv_flow_imp.g_varchar2_table(7) := '6E2869297B6C657420733D6E657720496D6167653B732E6F6E6C6F61643D66756E6374696F6E28297B6C657420693D646F63756D656E742E637265617465456C656D656E74282263616E76617322292C723D692E676574436F6E74657874282232642229';
wwv_flow_imp.g_varchar2_table(8) := '3B722E64726177496D61676528732C302C30293B6C6574206F2C6C2C703D732E77696474682C633D732E6865696768743B703E633F286F3D703E613F613A702C6C3D703E613F632A28612F70293A632A28702F6129293A286C3D633E6E3F6E3A632C6F3D';
wwv_flow_imp.g_varchar2_table(9) := '633E6E3F702A286E2F63293A702A28632F6E29292C692E77696474683D6F2C692E6865696768743D6C2C723D692E676574436F6E746578742822326422292C722E64726177496D61676528732C302C302C6F2C6C292C692E746F426C6F622866756E6374';
wwv_flow_imp.g_varchar2_table(10) := '696F6E2861297B74286E65772046696C65285B615D2C652E6E616D652C7B747970653A652E747970652C6C6173744D6F6469666965643A286E65772044617465292E67657454696D6528297D29297D2C652E747970652C2E3835297D2C732E7372633D69';
wwv_flow_imp.g_varchar2_table(11) := '2E7461726765742E726573756C747D2C692E7265616441734461746155524C2865297D7D297D66756E6374696F6E20792865297B6C657420743D6F28582E70726576696577436F6E7461696E65722C617065782E6750616765436F6E7465787424293B22';
wwv_flow_imp.g_varchar2_table(12) := '494D47223D3D3D742E70726F7028227461674E616D6522293F742E617474722822737263222C55524C2E6372656174654F626A65637455524C286529293A742E70726570656E64286F28223C696D673E222C7B7372633A55524C2E6372656174654F626A';
wwv_flow_imp.g_varchar2_table(13) := '65637455524C2865297D29297D66756E6374696F6E206828297B6C657420653D472E66696C65732C743D303B666F72286C657420613D303B613C652E6C656E6774683B612B2B297B6C6574206E3D655B615D2C693D715B712E66696E64496E6465782865';
wwv_flow_imp.g_varchar2_table(14) := '3D3E652E66696C652E6E616D653D3D3D6E2E6E616D65295D3B75286E292626692626692E66696C652626692E66696C652E73697A653C6E2E73697A653F742B3D692E66696C652E73697A657C7C303A742B3D6E2E73697A657C7C307D72657475726E2074';
wwv_flow_imp.g_varchar2_table(15) := '7D66756E6374696F6E207728297B6C657420653D303B666F72286C657420743D303B743C712E6C656E6774683B742B2B295B4F2C465D2E696E636C7564657328715B745D2E73746174757329262628652B3D715B745D2E66696C652E73697A657C7C3029';
wwv_flow_imp.g_varchar2_table(16) := '3B72657475726E20657D66756E6374696F6E205F2865297B692E636C6561724572726F727328292C692E73686F774572726F7273285B7B747970653A226572726F72222C6C6F636174696F6E3A5B2270616765225D2C706167654974656D3A6B2C6D6573';
wwv_flow_imp.g_varchar2_table(17) := '736167653A652C756E736166653A21317D5D297D6173796E632066756E6374696F6E206228652C74297B636F6E737420613D6828292C693D7728293B715B712E66696E64496E64657828653D3E652E66696C652E6E616D653D3D3D742E6E616D65295D2E';
wwv_flow_imp.g_varchar2_table(18) := '7374617475733D4C3B7472797B636F6E737420733D6177616974206F2E616A6178287B747970653A22504F5354222C75726C3A227777765F666C6F772E616A6178222C64617461547970653A226A736F6E222C70726F63657373446174613A21312C636F';
wwv_flow_imp.g_varchar2_table(19) := '6E74656E74547970653A21312C646174613A652C7868723A66756E6374696F6E28297B72657475726E20553D6F2E616A617853657474696E67732E78687228292C552E75706C6F61642E6F6E70726F67726573733D66756E6374696F6E2865297B696628';
wwv_flow_imp.g_varchar2_table(20) := '652E6C656E677468436F6D70757461626C65297B6E2E7472696767657228242C6A2C7B6E616D653A742E6E616D652C747970653A742E747970652C73697A653A742E73697A652C70726F67726573733A652E6C6F616465642F652E746F74616C2A313030';
wwv_flow_imp.g_varchar2_table(21) := '2C6C6F616465643A652E6C6F616465642C746F74616C3A652E746F74616C7D293B6C657420733D28692B652E6C6F61646564292F612A3130303B6E2E7472696767657228242C522C7B70726F67726573733A733E3130303F3130303A732C6C6F61646564';
wwv_flow_imp.g_varchar2_table(22) := '3A692B652E6C6F616465643E613F613A692B652E6C6F616465642C746F74616C3A617D297D7D2C557D7D293B72657475726E20737D63617463682865297B72657475726E204A3F284A3D21312C7B737563636573733A21307D293A7B737563636573733A';
wwv_flow_imp.g_varchar2_table(23) := '21312C6572726F723A657D7D7D6173796E632066756E6374696F6E20492865297B6C657420742C6E3D6E657720466F726D446174613B6E2E617070656E642822705F72657175657374222C22504C5547494E3D222B582E616A61784964656E7469666965';
wwv_flow_imp.g_varchar2_table(24) := '72292C6E2E617070656E642822705F666C6F775F6964222C732E4150505F4944292C6E2E617070656E642822705F666C6F775F737465705F6964222C732E4150505F504147455F4944292C6E2E617070656E642822705F696E7374616E6365222C732E41';
wwv_flow_imp.g_varchar2_table(25) := '50505F53455353494F4E292C6E2E617070656E642822705F6465627567222C247628227064656275672229292C6E2E617070656E642822463031222C652C652E6E616D65292C6E2E617070656E642822583031222C652E6E616D65292C6E2E617070656E';
wwv_flow_imp.g_varchar2_table(26) := '642822583032222C652E74797065292C652E5F6D6574616461746126266428652E5F6D657461646174612926266E2E617070656E642822583033222C4A534F4E2E737472696E6769667928652E5F6D6574616461746129293B666F72286C657420653D30';
wwv_flow_imp.g_varchar2_table(27) := '3B653C582E6974656D73546F5375626D69742E6C656E6774683B652B2B296E2E617070656E642822705F6172675F6E616D6573222C582E6974656D73546F5375626D69745B655D293B666F72286C657420653D303B653C582E6974656D73546F5375626D';
wwv_flow_imp.g_varchar2_table(28) := '69742E6C656E6774683B652B2B296E2E617070656E642822705F6172675F76616C756573222C6128582E6974656D73546F5375626D69745B655D292E67657456616C75652829293B72657475726E20743D61776169742062286E2C65292C747D6173796E';
wwv_flow_imp.g_varchar2_table(29) := '632066756E6374696F6E205328652C74297B6C657420612C693D21313B713D5B5D3B666F72286C657420743D303B743C652E6C656E6774683B742B2B297B6C657420733D655B745D2C6F3D7B7D3B732E747970657C7C28733D6E65772046696C65285B73';
wwv_flow_imp.g_varchar2_table(30) := '5D2C732E6E616D652C7B747970653A226170706C69636174696F6E2F6F637465742D73747265616D222C6C6173744D6F6469666965643A286E65772044617465292E67657454696D6528297D29292C5726266D285729262628733D617761697420572873';
wwv_flow_imp.g_varchar2_table(31) := '292C6F3D732E5F6D657461646174612C732E5F63616E63656C293F6E2E7472696767657228242C762C7B6E616D653A732E6E616D652C747970653A732E747970652C73697A653A732E73697A657D293A28582E656E61626C65496D616765526573697A65';
wwv_flow_imp.g_varchar2_table(32) := '262675287329262628733D617761697420782873292C582E656E61626C65496D61676550726576696577262679287329292C732E5F6D657461646174617C7C28732E5F6D657461646174613D6F7C7C7B7D292C483D7B6E616D653A732E6E616D652C7479';
wwv_flow_imp.g_varchar2_table(33) := '70653A732E747970652C73697A653A732E73697A657D2C712E70757368287B66696C653A732C7374617475733A447D292C613D617761697420492873292C612E737563636573733F28715B712E66696E64496E64657828653D3E652E66696C652E6E616D';
wwv_flow_imp.g_varchar2_table(34) := '653D3D3D732E6E616D65295D2E7374617475733D4F2C6E2E7472696767657228242C452C7B6E616D653A732E6E616D652C747970653A732E747970652C73697A653A732E73697A657D29293A28715B712E66696E64496E64657828653D3E652E66696C65';
wwv_flow_imp.g_varchar2_table(35) := '2E6E616D653D3D3D732E6E616D65295D2E7374617475733D462C6E2E7472696767657228242C432C7B6E616D653A732E6E616D652C747970653A732E747970652C73697A653A732E73697A652C6572726F723A612E6572726F727D292C5F28612E657272';
wwv_flow_imp.g_varchar2_table(36) := '6F722E73746174757354657874292C697C7C28693D213029292C722E696E666F287A2C732E6E616D652C6129297D742869297D636F6E7374207A3D22434F4D2E4F5241434C452E415045582E454E48414E4345445F46494C455F55504C4F41444552222C';
wwv_flow_imp.g_varchar2_table(37) := '503D22656E68616E63656466696C6575706C6F61646572222C453D502B2273756363657373222C433D502B226572726F72222C543D502B22636F6D706C657465222C763D502B2266696C6563616E63656C222C6A3D502B2266696C6570726F6772657373';
wwv_flow_imp.g_varchar2_table(38) := '222C523D502B22746F74616C70726F6772657373222C413D226469762E617065782D6974656D2D66696C6564726F70222C443D227374617274222C4C3D2275706C6F6164222C4F3D2273756363657373222C463D226572726F72223B6C657420552C4E2C';
wwv_flow_imp.g_varchar2_table(39) := '4D3D7B6166666563746564456C656D656E743A22222C656E61626C65496D616765526573697A653A21312C6D6178496D61676553697A653A313032342C656E61626C65496D616765507265766965773A21312C70726576696577436F6E7461696E65723A';
wwv_flow_imp.g_varchar2_table(40) := '22222C6974656D73546F5375626D69743A5B5D2C73686F7750726F63657373696E673A21302C63616E63656C576974684573636170653A21312C616A61784964656E7469666965723A22227D2C583D6F2E657874656E64287B7D2C4D2C70292C6B3D742E';
wwv_flow_imp.g_varchar2_table(41) := '65736361706543535328582E6166666563746564456C656D656E74292C473D646F63756D656E742E676574456C656D656E7442794964286B292C243D6F282223222B6B2C617065782E6750616765436F6E7465787424292C423D6C2C573D632C713D5B5D';
wwv_flow_imp.g_varchar2_table(42) := '2C483D7B7D2C4A3D21313B582E6974656D73546F5375626D6974262622737472696E67223D3D747970656F6620582E6974656D73546F5375626D6974262628582E6974656D73546F5375626D69743D582E6974656D73546F5375626D69742E73706C6974';
wwv_flow_imp.g_varchar2_table(43) := '28222C2229292C722E696E666F287A2C422C582C57292C582E63616E63656C5769746845736361706526266F28646F63756D656E74292E6B657975702866756E6374696F6E2865297B22457363617065223D3D3D652E6B65792626552626286E2E747269';
wwv_flow_imp.g_varchar2_table(44) := '6767657228242C762C48292C4A3D21302C552E61626F72742829297D292C472E66696C65732626472E66696C65732E6C656E6774683E302626286728292C5328472E66696C65732C66756E6374696F6E2874297B6628292C6E2E7472696767657228242C';
wwv_flow_imp.g_varchar2_table(45) := '54292C242E76616C282222292E6368616E676528292C652E726573756D6528422E726573756D6543616C6C6261636B2C74297D29297D7D2928617065782E64612C617065782E7574696C2C617065782E6974656D2C617065782E6576656E742C61706578';
wwv_flow_imp.g_varchar2_table(46) := '2E6D6573736167652C617065782E656E762C617065782E64656275672C617065782E6A5175657279293B';
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.4'
,p_default_workspace_id=>4206878434042097
,p_default_application_id=>102
,p_default_id_offset=>178159678296192488844
,p_default_owner=>'TEST'
);
wwv_flow_imp_shared.create_plugin_file(
 p_id=>wwv_flow_imp.id(226496794076348973992)
,p_plugin_id=>wwv_flow_imp.id(235418723369888032539)
,p_file_name=>'enhancedFileUpload.min.js'
,p_mime_type=>'application/javascript'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
