prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.4'
,p_default_workspace_id=>4206878434042097
,p_default_application_id=>102
,p_default_id_offset=>178159678296192488844
,p_default_owner=>'TEST'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Timeline'
,p_alias=>'TIMELINE'
,p_step_title=>'Timeline'
,p_allow_duplicate_submissions=>'N'
,p_reload_on_submit=>'A'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.actions.add([{',
'    name: "like",',
'    action: (event, element, args) => {',
'        apex.items.P1_ACTION_ID.value = args.id;',
'        apex.event.trigger(document, ''action-like'');',
'    }',
'}, {',
'    name: "delete",',
'    action: (event, element, args) => {',
'        apex.items.P1_ACTION_ID.value = args.id;',
'        apex.event.trigger(document, ''action-delete'');',
'    }',
'}, {',
'    name: "open-map",',
'    action: () => {',
'        apex.event.trigger(document, ''action-open-map'');',
'    }',
'}, {',
'    name: "open-about",',
'    action: () => {',
'        apex.event.trigger(document, ''action-open-about'');',
'    }',
'}]);'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.user-has-liked {',
'    color: red;',
'}',
'',
'@media (max-width: 640px) {',
'    .new-post-button {',
'        position: fixed;',
'        bottom: 24px;',
'        right: 24px;',
'        z-index: 1000;',
'    }',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_overwrite_navigation_list=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'JAYSON'
,p_last_upd_yyyymmddhh24miss=>'20230328225911'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(225405437216108427571)
,p_plug_name=>'Post'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-nosize:js-headingLevel-1'
,p_plug_template=>wwv_flow_imp.id(225397635080259754861)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_04'
,p_query_type=>'TABLE'
,p_query_table=>'SM_POSTS'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(225406305688641921846)
,p_plug_name=>'Timeline'
,p_region_name=>'timeline'
,p_region_css_classes=>'t-Chat'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(225397600523291754845)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    p.id,',
'    p.created_by AS user_name,',
'    p.post_comment AS comment_text,',
'    p.file_blob,',
'    p.file_mime,',
'    ',
'    apex_util.get_since(p.created) post_date,',
'',
'    (',
'        select count(*) from SM_REACTIONS smr ',
'        where smr.post_id=p.id',
'    ) as REACTIONS,',
'',
'    (',
'        select ''user-has-liked'' from SM_REACTIONS smr ',
'        where smr.post_id=p.id and created_by=:APP_USER',
'    ) USER_REACTION_CSS',
'',
'  from SM_POSTS p ',
'',
'  order by p.created desc'))
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(225435942205590581484)
,p_region_id=>wwv_flow_imp.id(225406305688641921846)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'USER_NAME'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'POST_DATE'
,p_body_adv_formatting=>false
,p_body_column_name=>'COMMENT_TEXT'
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'INITIALS'
,p_icon_class_column_name=>'USER_NAME'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
,p_media_source_type=>'BLOB'
,p_media_blob_column_name=>'FILE_BLOB'
,p_media_display_position=>'FIRST'
,p_media_appearance=>'WIDESCREEN'
,p_media_sizing=>'COVER'
,p_media_css_classes=>'selectDisable '
,p_media_description=>'&COMMENT_TEXT.'
,p_pk1_column_name=>'ID'
,p_mime_type_column_name=>'FILE_MIME'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(225435942382211581485)
,p_card_id=>wwv_flow_imp.id(225435942205590581484)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'&REACTIONS.'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#action$like?id=&ID.'
,p_button_display_type=>'TEXT_WITH_ICON'
,p_icon_css_classes=>'fa-heart &USER_REACTION_CSS.'
,p_action_css_classes=>'js-heart-button'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(225435942570350581487)
,p_card_id=>wwv_flow_imp.id(225435942205590581484)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>20
,p_label=>'Delete'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#action$delete?id=&ID.'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-trash-o'
,p_is_hot=>false
,p_condition_type=>'EXPRESSION'
,p_condition_expr1=>'trim(:user_name)=trim(:APP_USER)'
,p_condition_expr2=>'PLSQL'
,p_exec_cond_for_each_row=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(226134437724487256782)
,p_plug_name=>'Post and Like Locations'
,p_region_name=>'map'
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(225397635080259754861)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_04'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct lat, lon, created_by as who, apex_util.get_since(created) since from ',
'(',
'    select lat, lon, created_by, created from SM_POSTS ',
'union ',
'select lat, lon, created_by, created from SM_REACTIONS',
')'))
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(226134437797301256783)
,p_region_id=>wwv_flow_imp.id(226134437724487256782)
,p_height=>300
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'QUERY_RESULTS'
,p_init_position_from_browser=>true
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'MOUSEWHEEL_ZOOM:RECTANGLE_ZOOM:SCALE_BAR:INFINITE_MAP:BROWSER_LOCATION'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(226134437909417256784)
,p_map_region_id=>wwv_flow_imp.id(226134437797301256783)
,p_name=>'Locations'
,p_layer_type=>'POINT'
,p_display_sequence=>10
,p_location=>'REGION_SOURCE'
,p_has_spatial_index=>false
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LON'
,p_latitude_column=>'LAT'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>'&WHO. @ &SINCE.'
,p_info_window_adv_formatting=>false
,p_display_in_legend=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(226410205909703258853)
,p_plug_name=>'About'
,p_region_name=>'about'
,p_region_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_plug_template=>wwv_flow_imp.id(225397639687832754863)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_04'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'This application demonstrates many out-of-the-box features of APEX while also showing how an APEX developer can enhance and extend functionality with some custom HTML, mininmal CSS and some Javascript. Further, this application should behave beautifu'
||'lly on either Desktop or Mobile devices!',
'<h3>App Development concepts</h3>',
'<ul>',
'<li>Single Page Application</li>',
'<li>Progressive Web App</li>',
'<li>Mobile Friendly - can use device location and camera</li>',
'<li>File upload</li>',
'<li>Activity locations map</li>',
'</ul>',
'<h3>Database & APEX concepts</h3>',
'<ul>',
'<li>Page Designer</li>',
'<li>QuickSQL and relational datamodel</li>',
'<li>Form Region</li>',
'<li>Cards Region</li>',
'<li>Dialogs</li>',
'<li>Working with BLOBs</li>',
'<li>Javascript</li>',
'<li>Dynamic Actions</li>',
'<li>Custom Events</li>',
'<li>Custom HTML and CSS styling</li>',
'</ul>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(77685131117439192465)
,p_button_sequence=>10
,p_button_name=>'ADD_POST'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(225398132483184754905)
,p_button_image_alt=>'Add Post'
,p_button_position=>'AFTER_LOGO'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'new-post-button'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(225405442430944427576)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(225405437216108427571)
,p_button_name=>'SAVE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(225398132386120754905)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Post'
,p_button_position=>'NEXT'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'post-button'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(51930553754450808494)
,p_name=>'P1_POST_COMMENT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(225405437216108427571)
,p_item_source_plug_id=>wwv_flow_imp.id(225405437216108427571)
,p_prompt=>'Comment'
,p_source=>'POST_COMMENT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_imp.id(225398129805113754904)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(51930553836134808495)
,p_name=>'P1_FILE_BLOB'
,p_source_data_type=>'BLOB'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(225405437216108427571)
,p_item_source_plug_id=>wwv_flow_imp.id(225405437216108427571)
,p_prompt=>'Photo'
,p_source=>'FILE_BLOB'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(225398129529032754903)
,p_item_css_classes=>'file-upload'
,p_item_icon_css_classes=>'fa-camera-retro'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_attribute_01=>'DB_COLUMN'
,p_attribute_02=>'FILE_MIME'
,p_attribute_03=>'FILE_NAME'
,p_attribute_06=>'N'
,p_attribute_11=>'image/*'
,p_attribute_12=>'DROPZONE_BLOCK'
,p_attribute_13=>'Share a photo...'
,p_attribute_15=>'10000'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(225405437540539427572)
,p_name=>'P1_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(225405437216108427571)
,p_item_source_plug_id=>wwv_flow_imp.id(225405437216108427571)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(225435942721395581489)
,p_name=>'P1_ACTION_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(225406305688641921846)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
,p_item_comment=>'This ITEM has a DA on it that is set by the url''s calling JS code for the purpose, which initiates the server side code aspect easily'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(226109929383649716274)
,p_name=>'P1_LAT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(225405437216108427571)
,p_item_source_plug_id=>wwv_flow_imp.id(225405437216108427571)
,p_source=>'LAT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(226109929433951716275)
,p_name=>'P1_LON'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(225405437216108427571)
,p_item_source_plug_id=>wwv_flow_imp.id(225405437216108427571)
,p_source=>'LON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(225435942912717581491)
,p_name=>'action-delete'
,p_event_sequence=>90
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'document'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'action-delete'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(225435943249475581494)
,p_event_id=>wwv_flow_imp.id(225435942912717581491)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'DELETE Confirm dialog'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'You are about to delete this post. Are you sure?'
,p_attribute_02=>'Are you sure?'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(225435943052965581492)
,p_event_id=>wwv_flow_imp.id(225435942912717581491)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'DELETE - do database work'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'delete from SM_POSTS where id=:P1_ACTION_ID and created_by=:APP_USER;'
,p_attribute_02=>'P1_ACTION_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(226053824418739650448)
,p_event_id=>wwv_flow_imp.id(225435942912717581491)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_name=>'DELETE - remove post in UI'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''[data-id=''+apex.items.P1_ACTION_ID.value+'']'').remove();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(61394828436539055459)
,p_name=>'action-like'
,p_event_sequence=>100
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'document'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'action-like'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(61394828865920055463)
,p_event_id=>wwv_flow_imp.id(61394828436539055459)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_name=>'LIKE - update UI (adjust count + heart color)'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const button = $(''[data-id="''+ apex.items.P1_ACTION_ID.value +''"] .js-heart-button''); // get the card',
'',
'const label = button.find(''.a-CardView-buttonLabel''); // get the likes count section',
'',
'const icon = button.find(''.a-CardView-buttonIcon''); // gets the element if its liked already',
'',
'let likeCount = label.text(); // get the like count',
'',
'if (icon.hasClass(''user-has-liked'')) { ',
'    // user has liked this already, and they are unliking it now, decrement',
'    label.text(--likeCount); ',
'',
'} else { ',
'    // user is just now liking this, increment',
'    label.text(++likeCount);',
'}',
'',
'icon.toggleClass(''user-has-liked''); // either add this class or remove it'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(61394828991518055464)
,p_event_id=>wwv_flow_imp.id(61394828436539055459)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_name=>'LIKE - do database work'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    -- try to store this posts'' reaction from this user',
'    insert into SM_REACTIONS (post_id, reaction, lat, lon) values (:P1_ACTION_ID, ''LIKED'', :P1_LAT, :P1_LON);',
'    exception when dup_val_on_index then',
'        -- remove it as it already existed',
'        delete from SM_REACTIONS where post_id=:P1_ACTION_ID and created_by=:APP_USER;',
'end;'))
,p_attribute_02=>'P1_ACTION_ID,P1_LAT,P1_LON'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(55252870291075480456)
,p_name=>'action-open-map'
,p_event_sequence=>110
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'document'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'action-open-map'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(55252870879878480462)
,p_event_id=>wwv_flow_imp.id(55252870291075480456)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(226134437724487256782)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(55252870605366480459)
,p_name=>'action-open-about'
,p_event_sequence=>120
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'document'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'action-open-about'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(55252870930235480463)
,p_event_id=>wwv_flow_imp.id(55252870605366480459)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(226410205909703258853)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(77685131181893192466)
,p_name=>'Open Post Dialog'
,p_event_sequence=>130
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(77685131117439192465)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77685131335860192467)
,p_event_id=>wwv_flow_imp.id(77685131181893192466)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(225405437216108427571)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(61394829200730055466)
,p_name=>'Submit post'
,p_event_sequence=>140
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(225405442430944427576)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(61394829237876055467)
,p_event_id=>wwv_flow_imp.id(61394829200730055466)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'SAVE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(61394829316145055468)
,p_name=>'get device location'
,p_event_sequence=>150
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(61394829482196055469)
,p_event_id=>wwv_flow_imp.id(61394829316145055468)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_GET_CURRENT_POSITION'
,p_attribute_01=>'lat_long'
,p_attribute_03=>'P1_LAT'
,p_attribute_04=>'P1_LON'
,p_attribute_06=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(225406309686750921886)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(225405437216108427571)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'insert post'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(225405442430944427576)
,p_process_success_message=>'Posted!'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(225406307872352921868)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(225405437216108427571)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'init form'
);
wwv_flow_imp.component_end;
end;
/
